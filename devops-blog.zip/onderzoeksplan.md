# Onderzoeksplan

## Vragen

### Hoofdvraag

Hoe kan het gebruik van New Relic een applicatie verbeteren

### Deelvragen

- Wat zijn de usecases waarbinnen New Relic ondersteuning kan bieden?
- Wat zijn de voordelen van het gebruik van New Relic?
- Wat zijn de zorgpunten bij het gebruik van New Relic?
- Hoe gebruik je New Relic

## Plan

