# Template voor blogpost New Relic

*Daniël Groenendijk*, oktober 2023

## INHOUD

- intro
- omschrijving pitstop usecase
- omschrijving new relic rol binnen pitstop
- details over new relic
- voordelen new relic
- nadelen new relic
- set up binnen project en andere vereisten
- conclusie

## Bronnen
